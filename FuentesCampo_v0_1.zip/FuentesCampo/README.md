# Fuentes Campo (Android)

Primera versión de la app Android de campo para fuentes.

## Objetivo
Aplicación ligera para usar en móvil durante el muestreo, sin CSV ni analíticas LIMS.

## Incluye
- 185 fuentes con nombre y coordenadas integradas en `assets/fuentes.json`.
- Código normalizado siempre como `F-número`.
- Búsqueda exacta por `36`, `F36` o `F-36`.
- Búsqueda por nombre (incluye alias históricos).
- Selección de hasta 8 fuentes.
- Orden manual de la ruta.
- Apertura de ruta completa en Google Maps.
- Navegación individual a una fuente.
- Marcado de fuentes visitadas.
- Selección y visitadas persistentes al cerrar la app.
- Botón Atrás: vuelve a Fuentes desde Mapa/Ruta; en la pantalla principal requiere doble pulsación para salir.
- Mapa a pantalla completa dentro de la app con capas Calles y Satélite.

## Datos
Los datos se generan a partir de:
- `Puntos_potables.json`: nombres/metadatos.
- `coordenadas_fuentes.json`: coordenadas.

Solo se incorporan puntos cuyo código sea una fuente `F...`.
Las variantes `F36`, `F-36`, `f 36` se consolidan como `F-36`.

## Compilación
Abrir la carpeta `FuentesCampo` con Android Studio, dejar que sincronice Gradle y ejecutar en un dispositivo Android.
Configuración actual:
- minSdk 24
- targetSdk 35
- Java 17
- package `org.vitoria.fuentescampo`

La lista y las coordenadas funcionan sin Internet. El mapa base y Google Maps necesitan conexión, salvo que el teléfono tenga sus mapas ya disponibles/caché.
