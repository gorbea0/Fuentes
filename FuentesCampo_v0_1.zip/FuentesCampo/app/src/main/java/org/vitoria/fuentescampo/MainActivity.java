
package org.vitoria.fuentescampo;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.graphics.Typeface;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {

    static class Fuente {
        int numero;
        String codigo;
        String nombre;
        String za;
        double lat;
        double lng;
        List<String> aliases = new ArrayList<>();
    }

    private final List<Fuente> fuentes = new ArrayList<>();
    private final List<Integer> selectedOrder = new ArrayList<>();
    private final Set<Integer> visited = new HashSet<>();

    private LinearLayout content;
    private Button navFuentes, navMapa, navRuta;
    private int currentTab = 0;
    private EditText searchBox;
    private TextView selectedBadge;
    private WebView mapWeb;
    private LinearLayout routeList;
    private final Pattern exactCode = Pattern.compile("^\\s*(?:[Ff]\\s*-?\\s*)?(\\d+)\\s*$");
    private long lastBackPress = 0L;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loadData();
        loadState();
        buildShell();
        showFuentes();
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private TextView tv(String text, int sp, int color) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        return b;
    }

    private void loadData() {
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(getAssets().open("fuentes.json"), StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            JSONArray arr = new JSONArray(sb.toString());
            for (int i=0;i<arr.length();i++) {
                JSONObject o=arr.getJSONObject(i);
                Fuente f=new Fuente();
                f.numero=o.getInt("numero");
                f.codigo=o.getString("codigo");
                f.nombre=o.optString("nombre", f.codigo);
                f.za=o.optString("za","");
                f.lat=o.getDouble("lat");
                f.lng=o.getDouble("lng");
                JSONArray al=o.optJSONArray("aliases");
                if(al!=null) for(int j=0;j<al.length();j++) f.aliases.add(al.optString(j));
                fuentes.add(f);
            }
            Collections.sort(fuentes, Comparator.comparingInt(a -> a.numero));
        } catch(Exception e) {
            Toast.makeText(this,"No se pudieron cargar las fuentes",Toast.LENGTH_LONG).show();
        }
    }

    private void loadState() {
        String sel=getPreferences(MODE_PRIVATE).getString("selected","[]");
        String vis=getPreferences(MODE_PRIVATE).getString("visited","[]");
        try {
            JSONArray a=new JSONArray(sel);
            for(int i=0;i<a.length();i++) selectedOrder.add(a.getInt(i));
        } catch(Exception ignored){}
        try {
            JSONArray a=new JSONArray(vis);
            for(int i=0;i<a.length();i++) visited.add(a.getInt(i));
        } catch(Exception ignored){}
    }

    private void saveState() {
        JSONArray a=new JSONArray(); for(int n:selectedOrder)a.put(n);
        JSONArray v=new JSONArray(); for(int n:visited)v.put(n);
        getPreferences(MODE_PRIVATE).edit()
                .putString("selected",a.toString())
                .putString("visited",v.toString())
                .apply();
    }

    private void buildShell() {
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(248,250,252));

        LinearLayout header=new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(14),dp(10),dp(14),dp(8));
        header.setBackgroundColor(Color.WHITE);

        TextView title=tv("⛲ Fuentes Campo",21,Color.rgb(15,23,42));
        title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        header.addView(title,new LinearLayout.LayoutParams(0,dp(48),1));

        selectedBadge=tv("",13,Color.rgb(30,64,175));
        selectedBadge.setGravity(Gravity.CENTER);
        selectedBadge.setPadding(dp(10),dp(5),dp(10),dp(5));
        header.addView(selectedBadge,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,dp(42)));
        root.addView(header);

        content=new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        root.addView(content,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,0,1));

        LinearLayout bottom=new LinearLayout(this);
        bottom.setOrientation(LinearLayout.HORIZONTAL);
        bottom.setBackgroundColor(Color.WHITE);
        bottom.setPadding(dp(4),dp(4),dp(4),dp(4));

        navFuentes=button("📋 Fuentes");
        navMapa=button("🗺️ Mapa");
        navRuta=button("🚗 Ruta");
        navFuentes.setOnClickListener(v->showFuentes());
        navMapa.setOnClickListener(v->showMapa());
        navRuta.setOnClickListener(v->showRuta());

        bottom.addView(navFuentes,new LinearLayout.LayoutParams(0,dp(58),1));
        bottom.addView(navMapa,new LinearLayout.LayoutParams(0,dp(58),1));
        bottom.addView(navRuta,new LinearLayout.LayoutParams(0,dp(58),1));
        root.addView(bottom);

        setContentView(root);
        updateBadge();
    }

    private void setActiveTab(int tab) {
        currentTab=tab;
        navFuentes.setEnabled(tab!=0);
        navMapa.setEnabled(tab!=1);
        navRuta.setEnabled(tab!=2);
    }

    private void updateBadge() {
        if(selectedBadge==null)return;
        selectedBadge.setText(selectedOrder.size()+"/8");
    }

    private void clearContent() {
        content.removeAllViews();
        mapWeb=null;
        routeList=null;
    }

    private void showFuentes() {
        setActiveTab(0);
        clearContent();

        LinearLayout toolbar=new LinearLayout(this);
        toolbar.setOrientation(LinearLayout.VERTICAL);
        toolbar.setPadding(dp(10),dp(8),dp(10),dp(6));
        toolbar.setBackgroundColor(Color.WHITE);

        searchBox=new EditText(this);
        searchBox.setSingleLine(true);
        searchBox.setHint("Buscar F36, F-36, 36 o nombre");
        searchBox.setTextSize(16);
        toolbar.addView(searchBox,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(52)));

        TextView info=tv("Código numérico = coincidencia exacta. Máximo 8 fuentes.",12,Color.rgb(100,116,139));
        info.setPadding(dp(4),0,dp(4),dp(4));
        toolbar.addView(info);
        content.addView(toolbar);

        ListView list=new ListView(this);
        list.setDividerHeight(1);
        content.addView(list,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,0,1));

        final SourceAdapter adapter=new SourceAdapter(this,filterSources(""));
        list.setAdapter(adapter);
        searchBox.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int b,int c){ adapter.setItems(filterSources(s.toString())); }
            public void afterTextChanged(Editable e){}
        });
    }

    private List<Fuente> filterSources(String raw) {
        String q=raw==null?"":raw.trim();
        if(q.isEmpty()) return new ArrayList<>(fuentes);
        Matcher m=exactCode.matcher(q);
        if(m.matches()) {
            int n=Integer.parseInt(m.group(1));
            List<Fuente> out=new ArrayList<>();
            for(Fuente f:fuentes) if(f.numero==n) out.add(f);
            return out;
        }
        String nq=norm(q);
        List<Fuente> out=new ArrayList<>();
        for(Fuente f:fuentes) {
            boolean ok=norm(f.nombre).contains(nq) || norm(f.codigo).contains(nq);
            if(!ok) for(String a:f.aliases) if(norm(a).contains(nq)){ok=true;break;}
            if(ok)out.add(f);
        }
        return out;
    }

    private String norm(String s) {
        return java.text.Normalizer.normalize(s==null?"":s,java.text.Normalizer.Form.NFD)
                .replaceAll("\\p{M}","").toLowerCase(Locale.ROOT);
    }

    private class SourceAdapter extends BaseAdapter {
        Context ctx;
        List<Fuente> items;
        SourceAdapter(Context c,List<Fuente> x){ctx=c;items=x;}
        void setItems(List<Fuente>x){items=x;notifyDataSetChanged();}
        public int getCount(){return items.size();}
        public Object getItem(int p){return items.get(p);}
        public long getItemId(int p){return items.get(p).numero;}
        public View getView(int p,View convert,ViewGroup parent){
            Fuente f=items.get(p);
            LinearLayout row=new LinearLayout(ctx);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(12),dp(8),dp(8),dp(8));
            row.setBackgroundColor(Color.WHITE);

            CheckBox cb=new CheckBox(ctx);
            cb.setChecked(selectedOrder.contains(f.numero));
            cb.setOnClickListener(v->{
                boolean want=((CheckBox)v).isChecked();
                if(want&&!selectFuente(f.numero)) ((CheckBox)v).setChecked(false);
                if(!want) unselectFuente(f.numero);
                notifyDataSetChanged();
            });
            row.addView(cb,new LinearLayout.LayoutParams(dp(48),dp(48)));

            LinearLayout text=new LinearLayout(ctx);
            text.setOrientation(LinearLayout.VERTICAL);
            TextView code=tv(f.codigo+(visited.contains(f.numero)?"  ✓":""),17,
                    visited.contains(f.numero)?Color.rgb(22,101,52):Color.rgb(15,23,42));
            code.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
            TextView name=tv(f.nombre,14,Color.rgb(51,65,85));
            text.addView(code);
            text.addView(name);
            if(f.za!=null&&!f.za.isEmpty()){
                TextView za=tv(f.za,11,Color.rgb(100,116,139));
                text.addView(za);
            }
            row.addView(text,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));

            Button go=button("📍");
            go.setOnClickListener(v->openSourceDialog(f));
            row.addView(go,new LinearLayout.LayoutParams(dp(56),dp(48)));
            row.setOnClickListener(v->openSourceDialog(f));
            return row;
        }
    }

    private boolean selectFuente(int n) {
        if(selectedOrder.contains(n))return true;
        if(selectedOrder.size()>=8){
            Toast.makeText(this,"Ya hay 8 fuentes seleccionadas",Toast.LENGTH_SHORT).show();
            return false;
        }
        selectedOrder.add(n);
        saveState();
        updateBadge();
        refreshMapIfOpen();
        return true;
    }

    private void unselectFuente(int n) {
        selectedOrder.remove((Integer)n);
        saveState();updateBadge();refreshMapIfOpen();
    }

    private void toggleVisited(int n) {
        if(visited.contains(n))visited.remove(n);else visited.add(n);
        saveState();refreshMapIfOpen();
    }

    private Fuente byNum(int n){
        for(Fuente f:fuentes) if(f.numero==n)return f;
        return null;
    }

    private void openSourceDialog(Fuente f){
        boolean sel=selectedOrder.contains(f.numero);
        boolean vis=visited.contains(f.numero);
        String[] opts=new String[]{
                sel?"Quitar de la ruta":"Seleccionar para ruta",
                vis?"Marcar como pendiente":"✓ Marcar visitada",
                "Navegar a "+f.codigo,
                "Ver en mapa"
        };
        new AlertDialog.Builder(this)
                .setTitle(f.codigo+" · "+f.nombre)
                .setItems(opts,(d,which)->{
                    if(which==0){
                        if(sel)unselectFuente(f.numero);else selectFuente(f.numero);
                        if(currentTab==0)showFuentes(); else if(currentTab==1)showMapa(); else showRuta();
                    }
                    if(which==1){
                        toggleVisited(f.numero);
                        if(currentTab==0)showFuentes(); else if(currentTab==1)showMapa(); else showRuta();
                    }
                    if(which==2)navigateTo(f);
                    if(which==3){showMapa(); focusMap(f.numero);}
                }).show();
    }

    private void navigateTo(Fuente f){
        Uri uri=Uri.parse("google.navigation:q="+f.lat+","+f.lng+"&mode=d");
        Intent intent=new Intent(Intent.ACTION_VIEW,uri);
        intent.setPackage("com.google.android.apps.maps");
        try { startActivity(intent); }
        catch(Exception e){
            startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(
                    "https://www.google.com/maps/dir/?api=1&destination="+f.lat+","+f.lng+"&travelmode=driving")));
        }
    }

    private void showMapa() {
        setActiveTab(1);
        clearContent();

        LinearLayout top=new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setPadding(dp(8),dp(6),dp(8),dp(6));
        top.setBackgroundColor(Color.WHITE);

        EditText search=new EditText(this);
        search.setHint("F36 o nombre");
        search.setSingleLine(true);
        top.addView(search,new LinearLayout.LayoutParams(0,dp(48),1));
        Button go=button("Buscar");
        top.addView(go,new LinearLayout.LayoutParams(dp(90),dp(48)));
        content.addView(top);

        mapWeb=new WebView(this);
        mapWeb.setWebViewClient(new WebViewClient());
        mapWeb.setWebChromeClient(new WebChromeClient());
        mapWeb.getSettings().setJavaScriptEnabled(true);
        mapWeb.getSettings().setDomStorageEnabled(true);
        mapWeb.addJavascriptInterface(new MapBridge(),"Android");
        content.addView(mapWeb,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,0,1));
        renderMapHtml();

        View.OnClickListener run=v->{
            List<Fuente> found=filterSources(search.getText().toString());
            if(found.size()==1) focusMap(found.get(0).numero);
            else if(found.size()>1) Toast.makeText(this,found.size()+" coincidencias por nombre",Toast.LENGTH_SHORT).show();
            else Toast.makeText(this,"No encontrada",Toast.LENGTH_SHORT).show();
        };
        go.setOnClickListener(run);
        search.setOnEditorActionListener((v,action,event)->{run.onClick(v);return true;});
    }

    private String jsEsc(String s){
        return s.replace("\\","\\\\").replace("'","\\'").replace("\n"," ");
    }

    private void renderMapHtml(){
        if(mapWeb==null)return;
        StringBuilder pts=new StringBuilder();
        for(Fuente f:fuentes){
            boolean sel=selectedOrder.contains(f.numero), vis=visited.contains(f.numero);
            String color=vis?"#16a34a":sel?"#2563eb":"#64748b";
            pts.append("{n:").append(f.numero)
                    .append(",c:'").append(jsEsc(f.codigo)).append("'")
                    .append(",name:'").append(jsEsc(f.nombre)).append("'")
                    .append(",lat:").append(f.lat).append(",lng:").append(f.lng)
                    .append(",color:'").append(color).append("'},");
        }
        String html="<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1,user-scalable=no'>"+
                "<link rel='stylesheet' href='https://unpkg.com/leaflet@1.9.4/dist/leaflet.css'/>"+
                "<script src='https://unpkg.com/leaflet@1.9.4/dist/leaflet.js'></script>"+
                "<style>html,body,#m{height:100%;margin:0}.leaflet-control-layers{font-size:13px}.pop button{padding:7px;margin:3px;border:1px solid #bbb;border-radius:6px;background:white}</style></head>"+
                "<body><div id='m'></div><script>"+
                "var map=L.map('m').setView([42.8528,-2.6772],13);"+
                "var osm=L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19});"+
                "var sat=L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',{maxZoom:19});"+
                "osm.addTo(map);L.control.layers({'Calles':osm,'Satélite':sat},null,{collapsed:true}).addTo(map);"+
                "var points=["+pts+"];var marks={};"+
                "points.forEach(function(p){var m=L.circleMarker([p.lat,p.lng],{radius:7,color:'#111827',weight:1,fillColor:p.color,fillOpacity:.9}).addTo(map);"+
                "m.bindTooltip(p.c,{permanent:false,direction:'top'});"+
                "m.bindPopup('<div class=\"pop\"><b>'+p.c+'</b><br>'+p.name+'<br><button onclick=\"Android.select('+p.n+')\">Seleccionar/Quitar</button><button onclick=\"Android.navigate('+p.n+')\">Navegar</button><button onclick=\"Android.visited('+p.n+')\">Visitada</button></div>');marks[p.n]=m;});"+
                "function focusN(n){var m=marks[n];if(m){map.setView(m.getLatLng(),18);m.openPopup();}}"+
                "</script></body></html>";
        mapWeb.loadDataWithBaseURL("https://local.fuentes/",html,"text/html","UTF-8",null);
    }

    private void focusMap(int n){
        if(mapWeb!=null) mapWeb.postDelayed(()->mapWeb.evaluateJavascript("focusN("+n+")",null),600);
    }

    private void refreshMapIfOpen(){
        if(currentTab==1 && mapWeb!=null) renderMapHtml();
    }

    public class MapBridge {
        @JavascriptInterface public void select(int n){
            runOnUiThread(()->{
                if(selectedOrder.contains(n))unselectFuente(n); else selectFuente(n);
                renderMapHtml();
            });
        }
        @JavascriptInterface public void navigate(int n){
            runOnUiThread(()->{Fuente f=byNum(n);if(f!=null)navigateTo(f);});
        }
        @JavascriptInterface public void visited(int n){
            runOnUiThread(()->{toggleVisited(n);renderMapHtml();});
        }
    }

    private void showRuta(){
        setActiveTab(2);
        clearContent();

        LinearLayout top=new LinearLayout(this);
        top.setOrientation(LinearLayout.VERTICAL);
        top.setPadding(dp(10),dp(8),dp(10),dp(8));
        top.setBackgroundColor(Color.WHITE);

        TextView h=tv("Fuentes seleccionadas: "+selectedOrder.size()+"/8",18,Color.rgb(15,23,42));
        h.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        top.addView(h);

        LinearLayout actions=new LinearLayout(this);
        Button maps=button("🚗 Abrir ruta");
        Button reset=button("Nueva jornada");
        maps.setEnabled(!selectedOrder.isEmpty());
        maps.setOnClickListener(v->openRoute());
        reset.setOnClickListener(v->confirmReset());
        actions.addView(maps,new LinearLayout.LayoutParams(0,dp(52),1));
        actions.addView(reset,new LinearLayout.LayoutParams(0,dp(52),1));
        top.addView(actions);
        content.addView(top);

        ScrollView sv=new ScrollView(this);
        routeList=new LinearLayout(this);
        routeList.setOrientation(LinearLayout.VERTICAL);
        routeList.setPadding(dp(8),dp(6),dp(8),dp(20));
        sv.addView(routeList);
        content.addView(sv,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,0,1));
        renderRouteList();
    }

    private void renderRouteList(){
        if(routeList==null)return;
        routeList.removeAllViews();
        if(selectedOrder.isEmpty()){
            TextView t=tv("No hay fuentes seleccionadas.\nVe a Fuentes o Mapa y marca hasta 8.",16,Color.rgb(100,116,139));
            t.setGravity(Gravity.CENTER);
            t.setPadding(dp(20),dp(70),dp(20),dp(20));
            routeList.addView(t);
            return;
        }
        for(int i=0;i<selectedOrder.size();i++){
            int n=selectedOrder.get(i);
            Fuente f=byNum(n); if(f==null)continue;
            final int idx=i;
            LinearLayout card=new LinearLayout(this);
            card.setOrientation(LinearLayout.HORIZONTAL);
            card.setGravity(Gravity.CENTER_VERTICAL);
            card.setPadding(dp(8),dp(8),dp(6),dp(8));
            card.setBackgroundColor(Color.WHITE);

            TextView order=tv(String.valueOf(i+1),18,Color.WHITE);
            order.setGravity(Gravity.CENTER);
            order.setBackgroundColor(Color.rgb(37,99,235));
            card.addView(order,new LinearLayout.LayoutParams(dp(38),dp(38)));

            LinearLayout text=new LinearLayout(this);text.setOrientation(LinearLayout.VERTICAL);text.setPadding(dp(10),0,dp(5),0);
            TextView c=tv(f.codigo+(visited.contains(n)?"  ✓":""),17,visited.contains(n)?Color.rgb(22,101,52):Color.rgb(15,23,42));
            c.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
            text.addView(c); text.addView(tv(f.nombre,13,Color.rgb(71,85,105)));
            card.addView(text,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));

            LinearLayout controls=new LinearLayout(this);controls.setOrientation(LinearLayout.VERTICAL);
            Button up=button("↑");Button down=button("↓");
            up.setEnabled(i>0);down.setEnabled(i<selectedOrder.size()-1);
            up.setOnClickListener(v->{Collections.swap(selectedOrder,idx,idx-1);saveState();renderRouteList();});
            down.setOnClickListener(v->{Collections.swap(selectedOrder,idx,idx+1);saveState();renderRouteList();});
            controls.addView(up,new LinearLayout.LayoutParams(dp(48),dp(42)));
            controls.addView(down,new LinearLayout.LayoutParams(dp(48),dp(42)));
            card.addView(controls);

            card.setOnClickListener(v->openSourceDialog(f));
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);
            cp.setMargins(0,0,0,dp(7));
            routeList.addView(card,cp);
        }
    }

    private void openRoute(){
        if(selectedOrder.isEmpty())return;
        List<Fuente> list=new ArrayList<>();
        for(int n:selectedOrder){Fuente f=byNum(n);if(f!=null)list.add(f);}
        Fuente dest=list.get(list.size()-1);
        StringBuilder u=new StringBuilder("https://www.google.com/maps/dir/?api=1&destination=")
                .append(dest.lat).append(",").append(dest.lng).append("&travelmode=driving");
        if(list.size()>1){
            u.append("&waypoints=");
            for(int i=0;i<list.size()-1;i++){
                if(i>0)u.append("%7C");
                u.append(list.get(i).lat).append("%2C").append(list.get(i).lng);
            }
        }
        Intent intent=new Intent(Intent.ACTION_VIEW,Uri.parse(u.toString()));
        try{intent.setPackage("com.google.android.apps.maps");startActivity(intent);}
        catch(Exception e){intent.setPackage(null);startActivity(intent);}
    }

    private void confirmReset(){
        new AlertDialog.Builder(this)
                .setTitle("Nueva jornada")
                .setMessage("¿Limpiar selección y marcas de visitada?")
                .setNegativeButton("Cancelar",null)
                .setPositiveButton("Limpiar",(d,w)->{
                    selectedOrder.clear();visited.clear();saveState();updateBadge();showRuta();
                }).show();
    }

    @Override public void onBackPressed(){
        if(currentTab!=0){
            showFuentes();
            return;
        }
        long now=System.currentTimeMillis();
        if(now-lastBackPress<1800){
            super.onBackPressed();
        } else {
            lastBackPress=now;
            Toast.makeText(this,"Pulsa atrás otra vez para salir",Toast.LENGTH_SHORT).show();
        }
    }
}
