# Fuentes de red Vitoria — v0.3.1

Cambios:
- Escudo oficial suministrado por el usuario en la ventana informativa.
- Botón “Abrir versión web” → https://gorbea0.github.io/Fuentes/
- Mantiene AGP 8.13.2 + Gradle 8.13.
- Compatible con JDK 17 o 21 para Gradle.
