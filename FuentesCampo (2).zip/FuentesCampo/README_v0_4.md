# Fuentes de red Vitoria — v0.4.0

Cambios de esta versión:
- Navegación corregida: Google Maps recibe exclusivamente latitud/longitud; el código F-xxx ya no forma parte de la consulta de navegación.
- Control de precisión GPS: solo usa posiciones recientes y razonablemente precisas; muestra la precisión estimada y rechaza lecturas muy imprecisas.
- Ficha de campo con fotografía opcional. Se guarda en almacenamiento privado y se reduce a un máximo aproximado de 1280 px, JPEG 72 %, para limitar el peso.
- Cloro combinado calculado automáticamente como `cloro total - cloro libre`.
- Informe por email con formato HTML cuando la aplicación de correo lo admite, con una ficha visual por fuente.
- Cada fuente incluye un enlace directo a sus coordenadas en Google Maps.
- Las fotografías de campo se adjuntan al correo.
- Al iniciar una nueva jornada se eliminan también las fotografías de campo almacenadas.

Nota: algunos clientes de correo pueden simplificar el formato HTML al componer el mensaje; en ese caso el contenido sigue siendo legible y los enlaces/adjuntos permanecen.
