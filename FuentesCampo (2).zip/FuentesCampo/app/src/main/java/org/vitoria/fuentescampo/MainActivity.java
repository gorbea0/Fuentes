
package org.vitoria.fuentescampo;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.net.Uri;
import android.provider.MediaStore;
import android.text.Html;
import android.text.Spanned;
import android.content.ClipData;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.graphics.Typeface;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import androidx.core.content.FileProvider;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {

    static class Fuente {
        int numero;
        String codigo;
        String nombre;
        String za;
        double lat;
        double lng;
        List<String> aliases = new ArrayList<>();
    }

    private final List<Fuente> fuentes = new ArrayList<>();
    private final List<Integer> selectedOrder = new ArrayList<>();
    private final Set<Integer> visited = new HashSet<>();
    private final Map<Integer, FieldData> fieldData = new HashMap<>();
    private static final int MAX_SOURCES = 20;
    private static final int REQ_LOCATION = 501;
    private static final int REQ_CAMERA = 502;
    private static final float GPS_GOOD_ACCURACY_M = 50f;
    private static final float GPS_MAX_ACCEPTABLE_M = 120f;
    static class FieldData { String registro="", hora="", cloroLibre="", cloroTotal="", temperatura="", obs="", photoPath=""; }
    private File pendingPhotoFile;
    private int pendingPhotoNumero = -1;

    private LinearLayout content;
    private Button navFuentes, navMapa, navRuta;
    private int currentTab = 0;
    private EditText searchBox;
    private TextView selectedBadge;
    private WebView mapWeb;
    private LinearLayout routeList;
    private final Pattern exactCode = Pattern.compile("^\\s*(?:[Ff]\\s*-?\\s*)?(\\d+)\\s*$");
    private long lastBackPress = 0L;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loadData();
        loadState();
        buildShell();
        showFuentes();
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private TextView tv(String text, int sp, int color) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        return b;
    }

    private void loadData() {
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(getAssets().open("fuentes.json"), StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            JSONArray arr = new JSONArray(sb.toString());
            for (int i=0;i<arr.length();i++) {
                JSONObject o=arr.getJSONObject(i);
                Fuente f=new Fuente();
                f.numero=o.getInt("numero");
                f.codigo=o.getString("codigo");
                f.nombre=o.optString("nombre", f.codigo);
                f.za=o.optString("za","");
                f.lat=o.getDouble("lat");
                f.lng=o.getDouble("lng");
                JSONArray al=o.optJSONArray("aliases");
                if(al!=null) for(int j=0;j<al.length();j++) f.aliases.add(al.optString(j));
                fuentes.add(f);
            }
            Collections.sort(fuentes, Comparator.comparingInt(a -> a.numero));
        } catch(Exception e) {
            Toast.makeText(this,"No se pudieron cargar las fuentes",Toast.LENGTH_LONG).show();
        }
    }

    private void loadState() {
        String sel=getPreferences(MODE_PRIVATE).getString("selected","[]");
        String vis=getPreferences(MODE_PRIVATE).getString("visited","[]");
        String fld=getPreferences(MODE_PRIVATE).getString("fieldData","{}");
        try {
            JSONArray a=new JSONArray(sel);
            for(int i=0;i<a.length();i++) selectedOrder.add(a.getInt(i));
        } catch(Exception ignored){}
        try {
            JSONArray a=new JSONArray(vis);
            for(int i=0;i<a.length();i++) visited.add(a.getInt(i));
        } catch(Exception ignored){}
        try { JSONObject o=new JSONObject(fld); Iterator<String> ks=o.keys(); while(ks.hasNext()){String k=ks.next();JSONObject d=o.getJSONObject(k);FieldData x=new FieldData();
            x.registro=d.optString("registro","");x.hora=d.optString("hora","");x.cloroLibre=d.optString("cloroLibre","");x.cloroTotal=d.optString("cloroTotal","");x.temperatura=d.optString("temperatura","");x.obs=d.optString("obs","");x.photoPath=d.optString("photoPath","");fieldData.put(Integer.parseInt(k),x);} } catch(Exception ignored){}
    }

    private void saveState() {
        JSONArray a=new JSONArray(); for(int n:selectedOrder)a.put(n);
        JSONArray v=new JSONArray(); for(int n:visited)v.put(n);
        JSONObject fd=new JSONObject(); try{for(Map.Entry<Integer,FieldData> e:fieldData.entrySet()){FieldData x=e.getValue();JSONObject d=new JSONObject();d.put("registro",x.registro);d.put("hora",x.hora);d.put("cloroLibre",x.cloroLibre);d.put("cloroTotal",x.cloroTotal);d.put("temperatura",x.temperatura);d.put("obs",x.obs);d.put("photoPath",x.photoPath);fd.put(String.valueOf(e.getKey()),d);}}catch(Exception ignored){}
        getPreferences(MODE_PRIVATE).edit()
                .putString("selected",a.toString())
                .putString("visited",v.toString())
                .putString("fieldData",fd.toString())
                .apply();
    }

    private void buildShell() {
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(248,250,252));

        LinearLayout header=new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(14),dp(10),dp(14),dp(8));
        header.setBackgroundColor(Color.WHITE);

        TextView title=tv("🚰 Fuentes de red Vitoria",20,Color.rgb(15,23,42));
        title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        title.setOnClickListener(v->showAboutDialog());
        header.addView(title,new LinearLayout.LayoutParams(0,dp(48),1));

        selectedBadge=tv("",13,Color.rgb(30,64,175));
        selectedBadge.setGravity(Gravity.CENTER);
        selectedBadge.setPadding(dp(10),dp(5),dp(10),dp(5));
        header.addView(selectedBadge,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,dp(42)));
        root.addView(header);

        content=new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        root.addView(content,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,0,1));

        LinearLayout bottom=new LinearLayout(this);
        bottom.setOrientation(LinearLayout.HORIZONTAL);
        bottom.setBackgroundColor(Color.WHITE);
        bottom.setPadding(dp(4),dp(4),dp(4),dp(4));

        navFuentes=button("📋 Fuentes");
        navMapa=button("🗺️ Mapa");
        navRuta=button("🚗 Ruta");
        navFuentes.setOnClickListener(v->showFuentes());
        navMapa.setOnClickListener(v->showMapa());
        navRuta.setOnClickListener(v->showRuta());

        bottom.addView(navFuentes,new LinearLayout.LayoutParams(0,dp(58),1));
        bottom.addView(navMapa,new LinearLayout.LayoutParams(0,dp(58),1));
        bottom.addView(navRuta,new LinearLayout.LayoutParams(0,dp(58),1));
        root.addView(bottom);

        setContentView(root);
        updateBadge();
    }

    private void setActiveTab(int tab) {
        currentTab=tab;
        navFuentes.setEnabled(tab!=0);
        navMapa.setEnabled(tab!=1);
        navRuta.setEnabled(tab!=2);
    }

    private void updateBadge() {
        if(selectedBadge==null)return;
        selectedBadge.setText(selectedOrder.size()+"/"+MAX_SOURCES);
    }

    private void clearContent() {
        content.removeAllViews();
        mapWeb=null;
        routeList=null;
    }

    private void showAboutDialog() {
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(dp(22),dp(8),dp(22),dp(8));

        ImageView shield=new ImageView(this);
        shield.setImageResource(R.drawable.escudo_vitoria);
        shield.setAdjustViewBounds(true);
        shield.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        LinearLayout.LayoutParams shieldLp=new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,dp(90));
        box.addView(shield,shieldLp);

        TextView corp=tv("Laboratorio Municipal de Vitoria-Gasteiz",18,Color.rgb(15,23,42));
        corp.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        corp.setGravity(Gravity.CENTER);
        box.addView(corp);

        TextView msg=tv("Esta aplicación muestra las fuentes públicas de la red de agua potable controladas por el Ayuntamiento de Vitoria-Gasteiz. Permite localizarlas, buscarlas y navegar hasta ellas para facilitar el trabajo de muestreo. Diseñado por Oscar Unzueta ver 1.0 2026",14,Color.rgb(51,65,85));
        msg.setPadding(0,dp(14),0,dp(4));
        msg.setGravity(Gravity.CENTER);
        box.addView(msg);

        AlertDialog dialog=new AlertDialog.Builder(this)
                .setView(box)
                .setNeutralButton("🌐 Abrir versión web",null)
                .setPositiveButton("Cerrar",null)
                .create();

        dialog.setOnShowListener(x -> {
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> {
                Intent web=new Intent(Intent.ACTION_VIEW,
                        Uri.parse("https://gorbea0.github.io/Fuentes/"));
                try{
                    startActivity(web);
                }catch(Exception e){
                    Toast.makeText(this,"No se pudo abrir el navegador",Toast.LENGTH_SHORT).show();
                }
            });
        });

        dialog.show();
    }

    private void showFuentes() {
        setActiveTab(0);
        clearContent();

        LinearLayout toolbar=new LinearLayout(this);
        toolbar.setOrientation(LinearLayout.VERTICAL);
        toolbar.setPadding(dp(10),dp(8),dp(10),dp(6));
        toolbar.setBackgroundColor(Color.WHITE);

        searchBox=new EditText(this);
        searchBox.setSingleLine(true);
        searchBox.setHint("Buscar F36, F-36, 36 o nombre");
        searchBox.setTextSize(16);
        toolbar.addView(searchBox,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(52)));

        content.addView(toolbar);

        ListView list=new ListView(this);
        list.setDividerHeight(1);
        content.addView(list,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,0,1));

        final SourceAdapter adapter=new SourceAdapter(this,filterSources(""));
        list.setAdapter(adapter);
        searchBox.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int b,int c){ adapter.setItems(filterSources(s.toString())); }
            public void afterTextChanged(Editable e){}
        });
    }

    private List<Fuente> filterSources(String raw) {
        String q=raw==null?"":raw.trim();
        if(q.isEmpty()) return new ArrayList<>(fuentes);
        Matcher m=exactCode.matcher(q);
        if(m.matches()) {
            String group=m.group(1);
            if(group==null) return new ArrayList<>();
            int n=Integer.parseInt(group);
            List<Fuente> out=new ArrayList<>();
            for(Fuente f:fuentes) if(f.numero==n) out.add(f);
            return out;
        }
        String nq=norm(q);
        List<Fuente> out=new ArrayList<>();
        for(Fuente f:fuentes) {
            boolean ok=norm(f.nombre).contains(nq) || norm(f.codigo).contains(nq);
            if(!ok) for(String a:f.aliases) if(norm(a).contains(nq)){ok=true;break;}
            if(ok)out.add(f);
        }
        return out;
    }

    private String norm(String s) {
        return java.text.Normalizer.normalize(s==null?"":s,java.text.Normalizer.Form.NFD)
                .replaceAll("\\p{M}","").toLowerCase(Locale.ROOT);
    }

    private class SourceAdapter extends BaseAdapter {
        Context ctx;
        List<Fuente> items;
        SourceAdapter(Context c,List<Fuente> x){ctx=c;items=x;}
        void setItems(List<Fuente>x){items=x;notifyDataSetChanged();}
        public int getCount(){return items.size();}
        public Object getItem(int p){return items.get(p);}
        public long getItemId(int p){return items.get(p).numero;}
        public View getView(int p,View convert,ViewGroup parent){
            Fuente f=items.get(p);
            LinearLayout row=new LinearLayout(ctx);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(12),dp(8),dp(8),dp(8));
            row.setBackgroundColor(Color.WHITE);

            CheckBox cb=new CheckBox(ctx);
            cb.setChecked(selectedOrder.contains(f.numero));
            cb.setOnClickListener(v->{
                boolean want=((CheckBox)v).isChecked();
                if(want&&!selectFuente(f.numero)) ((CheckBox)v).setChecked(false);
                if(!want) unselectFuente(f.numero);
                notifyDataSetChanged();
            });
            row.addView(cb,new LinearLayout.LayoutParams(dp(48),dp(48)));

            LinearLayout text=new LinearLayout(ctx);
            text.setOrientation(LinearLayout.VERTICAL);
            TextView code=tv(f.codigo+(visited.contains(f.numero)?"  ✓":""),17,
                    visited.contains(f.numero)?Color.rgb(22,101,52):Color.rgb(15,23,42));
            code.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
            TextView name=tv(f.nombre,14,Color.rgb(51,65,85));
            text.addView(code);
            text.addView(name);
            row.addView(text,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));

            Button go=button("📍");
            go.setOnClickListener(v->openSourceDialog(f));
            row.addView(go,new LinearLayout.LayoutParams(dp(56),dp(48)));
            row.setOnClickListener(v->openSourceDialog(f));
            return row;
        }
    }

    private boolean selectFuente(int n) {
        if(selectedOrder.contains(n))return true;
        if(selectedOrder.size()>=MAX_SOURCES){
            Toast.makeText(this,"Ya hay "+MAX_SOURCES+" fuentes seleccionadas",Toast.LENGTH_SHORT).show();
            return false;
        }
        selectedOrder.add(n);
        saveState();
        updateBadge();
        refreshMapIfOpen();
        return true;
    }

    private void unselectFuente(int n) {
        selectedOrder.remove((Integer)n);
        saveState();updateBadge();refreshMapIfOpen();
    }

    private void toggleVisited(int n) {
        if(visited.contains(n))visited.remove(n);else visited.add(n);
        saveState();refreshMapIfOpen();
    }

    private Fuente byNum(int n){
        for(Fuente f:fuentes) if(f.numero==n)return f;
        return null;
    }

    private void openSourceDialog(Fuente f){
        boolean sel=selectedOrder.contains(f.numero);
        boolean vis=visited.contains(f.numero);
        String[] opts=new String[]{
                sel?"Quitar de la ruta":"Seleccionar para ruta",
                vis?"Marcar como pendiente":"✓ Marcar visitada",
                "Navegar a "+f.codigo,
                "Ver en mapa"
        };
        new AlertDialog.Builder(this)
                .setTitle(f.codigo+" · "+f.nombre)
                .setItems(opts,(d,which)->{
                    if(which==0){
                        if(sel)unselectFuente(f.numero);else selectFuente(f.numero);
                        if(currentTab==0)showFuentes(); else if(currentTab==1)showMapa(); else showRuta();
                    }
                    if(which==1){
                        toggleVisited(f.numero);
                        if(currentTab==0)showFuentes(); else if(currentTab==1)showMapa(); else showRuta();
                    }
                    if(which==2)navigateTo(f);
                    if(which==3){showMapa(); focusMap(f.numero);}
                }).show();
    }

    private void navigateTo(Fuente f){
        String coords=String.format(Locale.US,"%.8f,%.8f",f.lat,f.lng);
        Uri uri=Uri.parse("google.navigation:q="+Uri.encode(coords)+"&mode=d");
        Intent intent=new Intent(Intent.ACTION_VIEW,uri);
        intent.setPackage("com.google.android.apps.maps");
        try { startActivity(intent); }
        catch(Exception e){
            String labelled=coords+"("+f.codigo+")";
            Uri fallback=Uri.parse("geo:0,0?q="+Uri.encode(labelled));
            startActivity(new Intent(Intent.ACTION_VIEW,fallback));
        }
    }

    private void showMapa() {
        setActiveTab(1);
        clearContent();

        LinearLayout top=new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setPadding(dp(8),dp(6),dp(8),dp(6));
        top.setBackgroundColor(Color.WHITE);

        EditText search=new EditText(this);
        search.setHint("F36, nombre o calle");
        search.setSingleLine(true);
        top.addView(search,new LinearLayout.LayoutParams(0,dp(48),1));
        Button go=button("Buscar");
        top.addView(go,new LinearLayout.LayoutParams(dp(82),dp(48)));
        Button loc=button("◎"); loc.setContentDescription("Mi ubicación / fuentes cercanas");
        top.addView(loc,new LinearLayout.LayoutParams(dp(54),dp(48)));
        content.addView(top);

        mapWeb=new WebView(this);
        mapWeb.setWebViewClient(new WebViewClient());
        mapWeb.setWebChromeClient(new WebChromeClient());
        mapWeb.getSettings().setJavaScriptEnabled(true);
        mapWeb.getSettings().setDomStorageEnabled(true);
        mapWeb.addJavascriptInterface(new MapBridge(),"Android");
        content.addView(mapWeb,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,0,1));
        renderMapHtml();

        View.OnClickListener run=v->{
            List<Fuente> found=filterSources(search.getText().toString());
            if(found.size()==1) focusMap(found.get(0).numero);
            else if(found.size()>1) Toast.makeText(this,found.size()+" coincidencias por nombre",Toast.LENGTH_SHORT).show();
            else {
                String q=search.getText().toString().trim();
                if(!q.isEmpty() && mapWeb!=null) mapWeb.evaluateJavascript("searchStreet('"+jsEsc(q)+"')",null);
                else Toast.makeText(this,"No encontrada",Toast.LENGTH_SHORT).show();
            }
        };
        go.setOnClickListener(run);
        search.setOnEditorActionListener((v,action,event)->{run.onClick(v);return true;});
        loc.setOnClickListener(v->requestCurrentLocation());
    }

    private String jsEsc(String s){
        return s.replace("\\","\\\\").replace("'","\\'").replace("\n"," ");
    }

    private void renderMapHtml(){
        if(mapWeb==null)return;
        StringBuilder pts=new StringBuilder();
        for(Fuente f:fuentes){
            boolean sel=selectedOrder.contains(f.numero), vis=visited.contains(f.numero);
            String color=vis?"#16a34a":sel?"#2563eb":"#64748b";
            pts.append("{n:").append(f.numero)
                    .append(",c:'").append(jsEsc(f.codigo)).append("'")
                    .append(",name:'").append(jsEsc(f.nombre)).append("'")
                    .append(",lat:").append(f.lat).append(",lng:").append(f.lng)
                    .append(",color:'").append(color).append("'},");
        }
        String html="<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1,user-scalable=no'>"+
                "<link rel='stylesheet' href='https://unpkg.com/leaflet@1.9.4/dist/leaflet.css'/>"+
                "<script src='https://unpkg.com/leaflet@1.9.4/dist/leaflet.js'></script>"+
                "<style>html,body,#m{height:100%;margin:0}.leaflet-control-layers{font-size:13px}.pop button{padding:7px;margin:3px;border:1px solid #bbb;border-radius:6px;background:white}</style></head>"+
                "<body><div id='m'></div><script>"+
                "var map=L.map('m').setView([42.8528,-2.6772],13);"+
                "var osm=L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19});"+
                "var sat=L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',{maxZoom:19});"+
                "osm.addTo(map);L.control.layers({'Calles':osm,'Satélite':sat},null,{collapsed:true}).addTo(map);"+
                "var points=["+pts+"];var marks={};"+
                "points.forEach(function(p){var m=L.circleMarker([p.lat,p.lng],{radius:7,color:'#111827',weight:1,fillColor:p.color,fillOpacity:.9}).addTo(map);"+
                "m.bindTooltip(p.c,{permanent:false,direction:'top'});"+
                "m.bindPopup('<div class=\"pop\"><b>'+p.c+'</b><br>'+p.name+'<br><button onclick=\"Android.select('+p.n+')\">Seleccionar/Quitar</button><button onclick=\"Android.navigate('+p.n+')\">Navegar</button><button onclick=\"Android.visited('+p.n+')\">Visitada</button></div>');marks[p.n]=m;});"+
                "var me=null;"+
                "function showMe(lat,lng){"+
                " if(me)map.removeLayer(me);"+
                " me=L.circleMarker([lat,lng],{radius:9,color:'#ffffff',weight:3,fillColor:'#0ea5e9',fillOpacity:1}).addTo(map).bindTooltip('Mi posición');"+
                " map.setView([lat,lng],16);"+
                "}"+
                "function searchStreet(q){"+
                " var url='https://nominatim.openstreetmap.org/search?format=json&limit=1&countrycodes=es&q='+encodeURIComponent(q+', Vitoria-Gasteiz');"+
                " fetch(url).then(function(r){return r.json();}).then(function(a){"+
                "  if(a&&a.length){var lat=parseFloat(a[0].lat),lon=parseFloat(a[0].lon);map.setView([lat,lon],17);L.popup().setLatLng([lat,lon]).setContent(a[0].display_name).openOn(map);}"+
                "  else{Android.message('Calle no encontrada');}"+
                " }).catch(function(){Android.message('No se pudo buscar la calle');});"+
                "}"+
                "function focusN(n){var m=marks[n];if(m){map.setView(m.getLatLng(),18);m.openPopup();}}"+
                "</script></body></html>";
        mapWeb.loadDataWithBaseURL("https://local.fuentes/",html,"text/html","UTF-8",null);
    }

    private void focusMap(int n){
        if(mapWeb!=null) mapWeb.postDelayed(()->mapWeb.evaluateJavascript("focusN("+n+")",null),600);
    }

    private void refreshMapIfOpen(){
        if(currentTab==1 && mapWeb!=null) renderMapHtml();
    }

    public class MapBridge {
        @JavascriptInterface public void message(String x){runOnUiThread(()->Toast.makeText(MainActivity.this,x,Toast.LENGTH_SHORT).show());}
        @JavascriptInterface public void select(int n){
            runOnUiThread(()->{
                if(selectedOrder.contains(n))unselectFuente(n); else selectFuente(n);
                renderMapHtml();
            });
        }
        @JavascriptInterface public void navigate(int n){
            runOnUiThread(()->{Fuente f=byNum(n);if(f!=null)navigateTo(f);});
        }
        @JavascriptInterface public void visited(int n){
            runOnUiThread(()->{toggleVisited(n);renderMapHtml();});
        }
    }

    private void showRuta(){
        setActiveTab(2);
        clearContent();

        LinearLayout top=new LinearLayout(this);
        top.setOrientation(LinearLayout.VERTICAL);
        top.setPadding(dp(10),dp(8),dp(10),dp(8));
        top.setBackgroundColor(Color.WHITE);

        TextView h=tv("Fuentes seleccionadas: "+selectedOrder.size()+"/"+MAX_SOURCES,18,Color.rgb(15,23,42));
        h.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        top.addView(h);

        LinearLayout actions=new LinearLayout(this);
        Button maps=button("🚗 Ruta"); Button email=button("✉ Enviar"); Button reset=button("Nueva");
        maps.setEnabled(!selectedOrder.isEmpty()); email.setEnabled(!selectedOrder.isEmpty());
        maps.setOnClickListener(v->openRoute()); email.setOnClickListener(v->sendSamplingEmail()); reset.setOnClickListener(v->confirmReset());
        actions.addView(maps,new LinearLayout.LayoutParams(0,dp(52),1));
        actions.addView(email,new LinearLayout.LayoutParams(0,dp(52),1));
        actions.addView(reset,new LinearLayout.LayoutParams(0,dp(52),1));
        top.addView(actions);
        content.addView(top);

        ScrollView sv=new ScrollView(this);
        routeList=new LinearLayout(this);
        routeList.setOrientation(LinearLayout.VERTICAL);
        routeList.setPadding(dp(8),dp(6),dp(8),dp(20));
        sv.addView(routeList);
        content.addView(sv,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,0,1));
        renderRouteList();
    }

    private void renderRouteList(){
        if(routeList==null)return;
        routeList.removeAllViews();
        if(selectedOrder.isEmpty()){
            TextView t=tv("No hay fuentes seleccionadas.\nVe a Fuentes o Mapa y marca hasta 20.",16,Color.rgb(100,116,139));
            t.setGravity(Gravity.CENTER);
            t.setPadding(dp(20),dp(70),dp(20),dp(20));
            routeList.addView(t);
            return;
        }
        for(int i=0;i<selectedOrder.size();i++){
            int n=selectedOrder.get(i);
            Fuente f=byNum(n); if(f==null)continue;
            final int idx=i;
            LinearLayout card=new LinearLayout(this);
            card.setOrientation(LinearLayout.HORIZONTAL);
            card.setGravity(Gravity.CENTER_VERTICAL);
            card.setPadding(dp(8),dp(8),dp(6),dp(8));
            card.setBackgroundColor(Color.WHITE);

            TextView order=tv(String.valueOf(i+1),18,Color.WHITE);
            order.setGravity(Gravity.CENTER);
            order.setBackgroundColor(Color.rgb(37,99,235));
            card.addView(order,new LinearLayout.LayoutParams(dp(38),dp(38)));

            LinearLayout text=new LinearLayout(this);text.setOrientation(LinearLayout.VERTICAL);text.setPadding(dp(10),0,dp(5),0);
            TextView c=tv(f.codigo+(visited.contains(n)?"  ✓":""),17,visited.contains(n)?Color.rgb(22,101,52):Color.rgb(15,23,42));
            c.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
            text.addView(c); text.addView(tv(f.nombre,13,Color.rgb(71,85,105)));
            card.addView(text,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));

            LinearLayout controls=new LinearLayout(this);controls.setOrientation(LinearLayout.VERTICAL);
            Button up=button("↑");Button down=button("↓");
            up.setEnabled(i>0);down.setEnabled(i<selectedOrder.size()-1);
            up.setOnClickListener(v->{Collections.swap(selectedOrder,idx,idx-1);saveState();renderRouteList();});
            down.setOnClickListener(v->{Collections.swap(selectedOrder,idx,idx+1);saveState();renderRouteList();});
            controls.addView(up,new LinearLayout.LayoutParams(dp(48),dp(42)));
            controls.addView(down,new LinearLayout.LayoutParams(dp(48),dp(42)));
            card.addView(controls);

            card.setOnClickListener(v->openFieldDialog(f));
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);
            cp.setMargins(0,0,0,dp(7));
            routeList.addView(card,cp);
        }
    }

    private void openRoute(){
        if(selectedOrder.isEmpty())return;
        List<Fuente> list=new ArrayList<>();
        for(int n:selectedOrder){Fuente f=byNum(n);if(f!=null)list.add(f);}
        Fuente dest=list.get(list.size()-1);
        StringBuilder u=new StringBuilder("https://www.google.com/maps/dir/?api=1&destination=")
                .append(dest.lat).append(",").append(dest.lng).append("&travelmode=driving");
        if(list.size()>1){
            u.append("&waypoints=");
            for(int i=0;i<list.size()-1;i++){
                if(i>0)u.append("%7C");
                u.append(list.get(i).lat).append("%2C").append(list.get(i).lng);
            }
        }
        Intent intent=new Intent(Intent.ACTION_VIEW,Uri.parse(u.toString()));
        try{intent.setPackage("com.google.android.apps.maps");startActivity(intent);}
        catch(Exception e){intent.setPackage(null);startActivity(intent);}
    }


    private EditText fieldInput(String hint,String value){
        EditText e=new EditText(this);e.setHint(hint);e.setText(value);e.setTextSize(15);return e;
    }

    private Double parseFieldNumber(String value){
        try{
            if(value==null)return null;
            String x=value.trim().replace(',','.');
            if(x.isEmpty())return null;
            return Double.parseDouble(x);
        }catch(Exception e){return null;}
    }

    private String combinedText(String libre,String total){
        Double l=parseFieldNumber(libre),t=parseFieldNumber(total);
        if(l==null||t==null)return "Cloro combinado: —";
        double c=t-l;
        return "Cloro combinado: "+String.format(Locale.getDefault(),"%.2f",c)+" mg/L";
    }

    private String combinedValue(String libre,String total){
        Double l=parseFieldNumber(libre),t=parseFieldNumber(total);
        if(l==null||t==null)return "";
        return String.format(Locale.getDefault(),"%.2f",t-l);
    }

    private void saveFieldDraft(FieldData d,EditText reg,EditText hora,EditText cl,EditText ct,EditText temp,EditText obs){
        d.registro=reg.getText().toString().trim();
        d.hora=hora.getText().toString().trim();
        d.cloroLibre=cl.getText().toString().trim();
        d.cloroTotal=ct.getText().toString().trim();
        d.temperatura=temp.getText().toString().trim();
        d.obs=obs.getText().toString().trim();
    }

    private void openFieldDialog(Fuente f){
        FieldData d=fieldData.containsKey(f.numero)?fieldData.get(f.numero):new FieldData();
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(18),0,dp(18),0);

        EditText reg=fieldInput("N.º registro (LIMS)",d.registro);
        EditText hora=fieldInput("Hora (HH:MM)",d.hora);
        EditText cl=fieldInput("Cloro libre (mg/L)",d.cloroLibre);
        EditText ct=fieldInput("Cloro total (mg/L)",d.cloroTotal);
        TextView combined=tv(combinedText(d.cloroLibre,d.cloroTotal),14,Color.rgb(30,64,175));
        combined.setPadding(dp(4),dp(6),dp(4),dp(6));
        EditText temp=fieldInput("Temperatura (°C)",d.temperatura);
        EditText obs=fieldInput("Observaciones",d.obs);
        Button photo=button(d.photoPath.isEmpty()?"📷 Añadir fotografía":"📷 Sustituir fotografía");
        TextView photoInfo=tv(d.photoPath.isEmpty()?"Sin fotografía":"Fotografía guardada",12,Color.rgb(71,85,105));
        ImageView preview=new ImageView(this);preview.setScaleType(ImageView.ScaleType.CENTER_CROP);
        if(!d.photoPath.isEmpty()){
            File pf=new File(d.photoPath);
            if(pf.exists())preview.setImageURI(Uri.fromFile(pf));
        }

        if(d.hora.isEmpty())hora.setText(new java.text.SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date()));
        box.addView(reg);box.addView(hora);box.addView(cl);box.addView(ct);box.addView(combined);box.addView(temp);box.addView(obs);box.addView(photo);box.addView(photoInfo);
        if(!d.photoPath.isEmpty())box.addView(preview,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(140)));

        TextWatcher watcher=new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int b,int c){combined.setText(combinedText(cl.getText().toString(),ct.getText().toString()));}
            public void afterTextChanged(Editable e){}
        };
        cl.addTextChangedListener(watcher);ct.addTextChangedListener(watcher);

        photo.setOnClickListener(v->{
            saveFieldDraft(d,reg,hora,cl,ct,temp,obs);
            fieldData.put(f.numero,d);saveState();
            takeFieldPhoto(f.numero);
        });

        new AlertDialog.Builder(this)
                .setTitle(f.codigo+" · "+f.nombre)
                .setView(box)
                .setNeutralButton("Navegar",(x,w)->navigateTo(f))
                .setNegativeButton("Cancelar",null)
                .setPositiveButton("Guardar",(x,w)->{
                    saveFieldDraft(d,reg,hora,cl,ct,temp,obs);
                    fieldData.put(f.numero,d);visited.add(f.numero);saveState();renderRouteList();
                }).show();
    }

    private void takeFieldPhoto(int numero){
        try{
            File dir=new File(getFilesDir(),"field_photos");
            if(!dir.exists())dir.mkdirs();
            Fuente pf=byNum(numero);
            String base=(pf==null?("FUENTE_"+numero):(pf.codigo+"_"+pf.nombre)).replaceAll("[^A-Za-z0-9áéíóúÁÉÍÓÚñÑ_-]+","_");
            pendingPhotoFile=new File(dir,base+"_"+new java.text.SimpleDateFormat("yyyy-MM-dd_HHmm",Locale.US).format(new Date())+".jpg");
            pendingPhotoNumero=numero;
            Uri uri=FileProvider.getUriForFile(this,getPackageName()+".fileprovider",pendingPhotoFile);
            Intent camera=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            camera.putExtra(MediaStore.EXTRA_OUTPUT,uri);
            camera.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(camera,REQ_CAMERA);
        }catch(Exception e){
            Toast.makeText(this,"No se pudo abrir la cámara",Toast.LENGTH_LONG).show();
        }
    }

    private void compressFieldPhoto(File file){
        try{
            BitmapFactory.Options bounds=new BitmapFactory.Options();bounds.inJustDecodeBounds=true;BitmapFactory.decodeFile(file.getAbsolutePath(),bounds);
            int sample=1;while(bounds.outWidth/sample>1280||bounds.outHeight/sample>1280)sample*=2;
            BitmapFactory.Options opt=new BitmapFactory.Options();opt.inSampleSize=sample;
            Bitmap bmp=BitmapFactory.decodeFile(file.getAbsolutePath(),opt);if(bmp==null)return;
            int w=bmp.getWidth(),h=bmp.getHeight();
            float scale=Math.min(1f,1280f/Math.max(w,h));
            Bitmap outBmp=bmp;
            if(scale<1f)outBmp=Bitmap.createScaledBitmap(bmp,Math.round(w*scale),Math.round(h*scale),true);
            FileOutputStream fos=new FileOutputStream(file,false);outBmp.compress(Bitmap.CompressFormat.JPEG,72,fos);fos.close();
            if(outBmp!=bmp)outBmp.recycle();bmp.recycle();
        }catch(Exception ignored){}
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==REQ_CAMERA&&resultCode==RESULT_OK&&pendingPhotoFile!=null&&pendingPhotoNumero>0){
            compressFieldPhoto(pendingPhotoFile);
            FieldData d=fieldData.containsKey(pendingPhotoNumero)?fieldData.get(pendingPhotoNumero):new FieldData();
            String oldPath=d.photoPath;
            d.photoPath=pendingPhotoFile.getAbsolutePath();fieldData.put(pendingPhotoNumero,d);saveState();
            if(oldPath!=null&&!oldPath.isEmpty()&&!oldPath.equals(d.photoPath)){
                try{new File(oldPath).delete();}catch(Exception ignored){}
            }
            Toast.makeText(this,"Fotografía guardada",Toast.LENGTH_SHORT).show();
            if(currentTab==2)renderRouteList();
        }
        pendingPhotoFile=null;pendingPhotoNumero=-1;
    }

    private String escHtml(String s){
        if(s==null)return "";
        return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;");
    }

    private String mapUrl(Fuente f){
        return "https://www.google.com/maps/search/?api=1&query="+String.format(Locale.US,"%.8f,%.8f",f.lat,f.lng);
    }

    private void sendSamplingEmail(){
        final ArrayList<Fuente> sampled=new ArrayList<>();
        for(int n:selectedOrder){
            Fuente f=byNum(n); FieldData d=fieldData.get(n);
            if(f!=null && d!=null && hasFieldData(d))sampled.add(f);
        }
        if(sampled.isEmpty()){
            Toast.makeText(this,"No hay fuentes con datos de campo para enviar",Toast.LENGTH_SHORT).show();
            return;
        }
        generateSamplingMap(sampled);
    }

    private boolean hasFieldData(FieldData d){
        return d!=null && !(d.registro.trim().isEmpty() && d.hora.trim().isEmpty() &&
                d.cloroLibre.trim().isEmpty() && d.cloroTotal.trim().isEmpty() &&
                d.temperatura.trim().isEmpty() && d.obs.trim().isEmpty() && d.photoPath.trim().isEmpty());
    }

    private void generateSamplingMap(ArrayList<Fuente> sampled){
        final Dialog dlg=new Dialog(this);
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(8),dp(8),dp(8),dp(8));
        box.addView(tv("Preparando mapa del muestreo…",14,Color.rgb(15,61,102)),new LinearLayout.LayoutParams(-1,dp(42)));
        WebView w=new WebView(this); w.getSettings().setJavaScriptEnabled(true); w.getSettings().setDomStorageEnabled(true);
        box.addView(w,new LinearLayout.LayoutParams(dp(900),dp(700))); dlg.setContentView(box); dlg.show();

        StringBuilder pts=new StringBuilder(); int idx=1;
        for(Fuente f:sampled){
            pts.append("{i:").append(idx++).append(",c:'").append(jsEsc(f.codigo)).append("',n:'")
               .append(jsEsc(f.nombre)).append("',lat:").append(f.lat).append(",lng:").append(f.lng).append("},");
        }
        String html="<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'>"+
          "<link rel='stylesheet' href='https://unpkg.com/leaflet@1.9.4/dist/leaflet.css'><script src='https://unpkg.com/leaflet@1.9.4/dist/leaflet.js'></script>"+
          "<style>html,body,#m{height:100%;margin:0}.leaflet-tooltip.sample{font:600 12px Arial;background:white;border:1px solid #64748b;box-shadow:none;padding:3px 5px}</style></head>"+
          "<body><div id='m'></div><script>var map=L.map('m');L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19}).addTo(map);"+
          "var p=["+pts+"],b=[];p.forEach(function(x){b.push([x.lat,x.lng]);var m=L.circleMarker([x.lat,x.lng],{radius:8,color:'#173b65',weight:2,fillColor:'#36b9e8',fillOpacity:1}).addTo(map);"+
          "m.bindTooltip(x.i+'. '+x.c+' · '+x.n,{permanent:true,direction:'top',className:'sample',offset:[0,-8]});});"+
          "if(b.length===1)map.setView(b[0],17);else map.fitBounds(b,{padding:[100,100],maxZoom:16});</script></body></html>";

        w.setWebViewClient(new WebViewClient(){
            @Override public void onPageFinished(WebView view,String url){
                view.postDelayed(()->{
                    File mapFile=captureSamplingMap(view);
                    dlg.dismiss();
                    sendSamplingEmailNow(sampled,mapFile);
                },2400);
            }
        });
        w.loadDataWithBaseURL("https://local.fuentes/",html,"text/html","UTF-8",null);
    }

    private File captureSamplingMap(WebView view){
        try{
            File dir=new File(getCacheDir(),"reports"); if(!dir.exists())dir.mkdirs();
            File out=new File(dir,"mapa_muestreo_"+new java.text.SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date())+".png");
            Bitmap bmp=Bitmap.createBitmap(Math.max(1,view.getWidth()),Math.max(1,view.getHeight()),Bitmap.Config.ARGB_8888);
            Canvas canvas=new Canvas(bmp); view.draw(canvas);
            FileOutputStream fos=new FileOutputStream(out,false); bmp.compress(Bitmap.CompressFormat.PNG,92,fos); fos.close(); bmp.recycle();
            return out;
        }catch(Exception e){ return null; }
    }

    private void sendSamplingEmailNow(ArrayList<Fuente> sampled,File mapFile){
        String date=new java.text.SimpleDateFormat("dd/MM/yyyy",Locale.getDefault()).format(new Date());
        String subject="Muestreo de fuentes-red fecha "+date;
        StringBuilder body=new StringBuilder();
        body.append("MUESTREO DE FUENTES DE RED\nLaboratorio Municipal de Vitoria-Gasteiz\nFecha: ").append(date)
            .append("\nFuentes muestreadas: ").append(sampled.size()).append("\n\n");

        ArrayList<Uri> attachments=new ArrayList<>();
        if(mapFile!=null&&mapFile.exists())try{attachments.add(FileProvider.getUriForFile(this,getPackageName()+".fileprovider",mapFile));}catch(Exception ignored){}

        int order=1;
        for(Fuente f:sampled){
            FieldData d=fieldData.get(f.numero); String comb=combinedValue(d.cloroLibre,d.cloroTotal);
            body.append("━━━━━━━━━━━━━━━━━━━━━━━━━━\n").append(order++).append(". ").append(f.codigo).append(" · ").append(f.nombre).append("\n\n");
            if(!d.registro.trim().isEmpty())body.append("N.º registro: ").append(d.registro).append("\n");
            if(!d.hora.trim().isEmpty())body.append("Hora: ").append(d.hora).append("\n");
            if(!d.cloroLibre.trim().isEmpty())body.append("Cloro libre: ").append(d.cloroLibre).append(" mg/L\n");
            if(!d.cloroTotal.trim().isEmpty())body.append("Cloro total: ").append(d.cloroTotal).append(" mg/L\n");
            if(!comb.isEmpty())body.append("Cloro combinado: ").append(comb).append(" mg/L\n");
            if(!d.temperatura.trim().isEmpty())body.append("Temperatura: ").append(d.temperatura).append(" °C\n");
            if(!d.obs.trim().isEmpty())body.append("Observaciones: ").append(d.obs).append("\n");
            body.append("Mapa: ").append(mapUrl(f)).append("\n\n");
            if(!d.photoPath.isEmpty()){
                File photo=new File(d.photoPath);
                if(photo.exists())try{attachments.add(FileProvider.getUriForFile(this,getPackageName()+".fileprovider",photo));}catch(Exception ignored){}
            }
        }
        body.append("━━━━━━━━━━━━━━━━━━━━━━━━━━\nInforme generado desde Fuentes de red Vitoria");

        Intent intent=new Intent(attachments.size()>1?Intent.ACTION_SEND_MULTIPLE:Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_EMAIL,new String[]{"labmunpal@vitoria-gasteiz.org"});
        intent.putExtra(Intent.EXTRA_SUBJECT,subject); intent.putExtra(Intent.EXTRA_TEXT,body.toString());
        if(attachments.size()==1)intent.putExtra(Intent.EXTRA_STREAM,attachments.get(0));
        else if(attachments.size()>1)intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM,attachments);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        if(!attachments.isEmpty()){
            ClipData clip=null;
            for(Uri u:attachments)clip=(clip==null)?ClipData.newRawUri("adjunto",u):addClipItem(clip,u);
            if(clip!=null)intent.setClipData(clip);
        }
        try{startActivity(Intent.createChooser(intent,"Enviar muestreo"));}
        catch(Exception e){
            String mailto="mailto:labmunpal@vitoria-gasteiz.org?subject="+Uri.encode(subject)+"&body="+Uri.encode(body.toString());
            try{startActivity(new Intent(Intent.ACTION_SENDTO,Uri.parse(mailto)));}catch(Exception x){Toast.makeText(this,"No hay aplicación de correo disponible",Toast.LENGTH_LONG).show();}
        }
    }

    private ClipData addClipItem(ClipData clip,Uri uri){
        clip.addItem(new ClipData.Item(uri)); return clip;
    }

    private void showCurrentLocation(android.location.Location l){
        if(l==null)return;
        if(l.hasAccuracy()&&l.getAccuracy()>GPS_MAX_ACCEPTABLE_M){
            Toast.makeText(this,"Precisión GPS insuficiente (±"+Math.round(l.getAccuracy())+" m). Espera unos segundos al aire libre.",Toast.LENGTH_LONG).show();
            return;
        }
        if(mapWeb!=null)mapWeb.evaluateJavascript("showMe("+l.getLatitude()+","+l.getLongitude()+")",null);
        Toast.makeText(this,"Precisión GPS: ±"+Math.round(l.getAccuracy())+" m",Toast.LENGTH_SHORT).show();
        showNearestDialog(l);
    }
    private void showNearestDialog(android.location.Location l){List<Fuente> near=new ArrayList<>(fuentes);Collections.sort(near,(a,b)->Double.compare(distanceMeters(l,a),distanceMeters(l,b)));int c=Math.min(8,near.size());String[] rows=new String[c];for(int i=0;i<c;i++){Fuente f=near.get(i);rows[i]=f.codigo+" · "+Math.round(distanceMeters(l,f))+" m\n"+f.nombre;}new AlertDialog.Builder(this).setTitle("Fuentes más cercanas").setItems(rows,(d,w)->focusMap(near.get(w).numero)).setNegativeButton("Cerrar",null).show();}
    private double distanceMeters(android.location.Location l,Fuente f){float[] r=new float[1];android.location.Location.distanceBetween(l.getLatitude(),l.getLongitude(),f.lat,f.lng,r);return r[0];}
   
private void requestCurrentLocation() {
    if (android.os.Build.VERSION.SDK_INT >= 23 &&
            checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION)
                    != android.content.pm.PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION)
                    != android.content.pm.PackageManager.PERMISSION_GRANTED) {

        requestPermissions(
                new String[]{
                        android.Manifest.permission.ACCESS_FINE_LOCATION,
                        android.Manifest.permission.ACCESS_COARSE_LOCATION
                },
                REQ_LOCATION
        );
        return;
    }

    locateNow();
}

private void locateNow() {
    if (android.os.Build.VERSION.SDK_INT >= 23 &&
            checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) != android.content.pm.PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
        Toast.makeText(this,"Falta permiso de ubicación",Toast.LENGTH_SHORT).show();return;
    }

    try {
        android.location.LocationManager lm=(android.location.LocationManager)getSystemService(LOCATION_SERVICE);
        android.location.Location best=null;
        long now=System.currentTimeMillis();
        for(String provider:lm.getProviders(true)){
            android.location.Location x=lm.getLastKnownLocation(provider);
            if(x==null)continue;
            long age=Math.abs(now-x.getTime());
            if(age>120000L)continue;
            if(best==null || x.getAccuracy()<best.getAccuracy())best=x;
        }
        if(best!=null && (!best.hasAccuracy() || best.getAccuracy()<=GPS_GOOD_ACCURACY_M)){
            showCurrentLocation(best);return;
        }

        Toast.makeText(this,"Obteniendo una ubicación GPS precisa…",Toast.LENGTH_SHORT).show();
        final android.location.Location[] candidate=new android.location.Location[]{best};
        final boolean[] resolved=new boolean[]{false};
        final android.location.LocationListener[] holder=new android.location.LocationListener[1];
        holder[0]=new android.location.LocationListener(){
            @Override public void onLocationChanged(android.location.Location location){
                if(location==null)return;
                if(candidate[0]==null || location.getAccuracy()<candidate[0].getAccuracy())candidate[0]=location;
                if(!resolved[0] && (!location.hasAccuracy() || location.getAccuracy()<=GPS_GOOD_ACCURACY_M)){
                    resolved[0]=true;
                    showCurrentLocation(location);
                    try{lm.removeUpdates(this);}catch(Exception ignored){}
                }
            }
            @Override public void onProviderEnabled(String provider){}
            @Override public void onProviderDisabled(String provider){}
        };

        lm.requestLocationUpdates(android.location.LocationManager.GPS_PROVIDER,500,0,holder[0]);
        if(lm.isProviderEnabled(android.location.LocationManager.NETWORK_PROVIDER))
            lm.requestLocationUpdates(android.location.LocationManager.NETWORK_PROVIDER,500,0,holder[0]);

        new android.os.Handler(getMainLooper()).postDelayed(()->{
            if(resolved[0])return;
            resolved[0]=true;
            try{lm.removeUpdates(holder[0]);}catch(Exception ignored){}
            android.location.Location c=candidate[0];
            if(c!=null && (!c.hasAccuracy() || c.getAccuracy()<=GPS_MAX_ACCEPTABLE_M))showCurrentLocation(c);
            else if(c!=null)Toast.makeText(this,"No se obtuvo suficiente precisión GPS (±"+Math.round(c.getAccuracy())+" m).",Toast.LENGTH_LONG).show();
            else Toast.makeText(this,"No se pudo obtener la ubicación",Toast.LENGTH_LONG).show();
        },12000L);

    } catch(SecurityException e){Toast.makeText(this,"No hay permiso de ubicación",Toast.LENGTH_SHORT).show();}
      catch(Exception e){Toast.makeText(this,"No se pudo obtener la ubicación",Toast.LENGTH_SHORT).show();}
}

   @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){super.onRequestPermissionsResult(requestCode,permissions,grantResults);if(requestCode==REQ_LOCATION&&grantResults.length>0&&grantResults[0]==android.content.pm.PackageManager.PERMISSION_GRANTED)locateNow();}

    private void clearFieldPhotos(){
        try{
            File dir=new File(getFilesDir(),"field_photos");
            File[] files=dir.listFiles();
            if(files!=null)for(File f:files)try{f.delete();}catch(Exception ignored){}
        }catch(Exception ignored){}
    }

    private void confirmReset(){
        new AlertDialog.Builder(this)
                .setTitle("Nueva jornada")
                .setMessage("¿Limpiar selección y marcas de visitada?")
                .setNegativeButton("Cancelar",null)
                .setPositiveButton("Limpiar",(d,w)->{
                    clearFieldPhotos();selectedOrder.clear();visited.clear();fieldData.clear();saveState();updateBadge();showRuta();
                }).show();
    }

    @Override public void onBackPressed(){
        if(currentTab!=0){
            showFuentes();
            return;
        }
        long now=System.currentTimeMillis();
        if(now-lastBackPress<1800){
            super.onBackPressed();
        } else {
            lastBackPress=now;
            Toast.makeText(this,"Pulsa atrás otra vez para salir",Toast.LENGTH_SHORT).show();
        }
    }
}
