# FuentesCampo v0.4.1
- Email en texto estructurado, con URLs explícitas de Google Maps.
- Mapa PNG único de las fuentes realmente muestreadas (con datos de campo), numeradas y etiquetadas con código + nombre.
- Fotos comprimidas adjuntas y nuevos nombres: código + nombre + fecha/hora.
- Cloro combinado automático.
- Navegación por coordenadas puras y control de precisión GPS.
